"""Static release checks: run `python tests/check_bundle.py` from the project directory."""
from pathlib import Path
import json,re,subprocess,sys
base=Path(__file__).resolve().parents[1]
manifest=json.loads((base/'sprite_manifest.json').read_text())
assert manifest['tileMs'] == 1000/3
assert manifest['fpsEquivalent'] == 18
assert (base/manifest['objects']['field']).is_file()
for items in manifest['animations'].values():
    assert len(items)==6
    for item in items: assert (base/item['src']).is_file(),item['src']
for item in manifest['idle'].values(): assert (base/item['src']).is_file(),item['src']
for item in manifest['objects'].values():
    if isinstance(item,dict): assert (base/item['src']).is_file()
index=(base/'index.html').read_text()
old=(base/'_original'/'index.html').read_text()
for token in ['function pathFor(', 'const config={meadow:', "showResult('ポフッ！'", "showResult('ごちそうさま！'"]:
    assert token in index,token
    assert token in old,token
assert 'tileMs = 1000/3' in index
assert 'function animationSegments(path)' in index
assert 'function spriteDraw(kind,a)' in index
assert "function drawField(t)" in index
assert "sprites_to_cut_from_video" not in index
assert 'brushTexture' not in index
print('PASS: manifest assets present, six-frame references and preserved game hooks')
